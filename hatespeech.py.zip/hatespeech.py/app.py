import json
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import sys
import os

# Import the classifier and cleaner from our previous scripts
from train_naive_bayes import NaiveBayesClassifier
from prepare_data import clean_text

# Global variables to hold the loaded model
nb_model = None

class HateSpeechHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            try:
                with open('index.html', 'rb') as f:
                    self.wfile.write(f.read())
            except FileNotFoundError:
                self.wfile.write(b"index.html not found. Please create it.")
        else:
            self.send_error(404, "File not found")

    def do_POST(self):
        if self.path == '/predict':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            
            try:
                data = json.loads(post_data.decode('utf-8'))
                text = data.get('text', '')
                
                # 1. Clean the text
                cleaned = clean_text(text)
                
                # 2. Predict using the global nb_model
                if nb_model is not None:
                    # predict expects a list of texts
                    predictions = nb_model.predict([cleaned])
                    class_idx = predictions[0]
                    
                    # 0: Hate Speech, 1: Offensive, 2: Neither
                    class_names = {
                        0: "Hate Speech",
                        1: "Offensive Language",
                        2: "Neither"
                    }
                    
                    result = class_names.get(class_idx, "Unknown")
                    
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    response = json.dumps({'result': result, 'cleaned_text': cleaned})
                    self.wfile.write(response.encode('utf-8'))
                else:
                    self.send_error(500, "Model not loaded")
                    
            except Exception as e:
                self.send_error(400, f"Bad request: {str(e)}")
        else:
            self.send_error(404, "Endpoint not found")

def run_server(port=8080):
    global nb_model
    print("Loading model from nb_model.json...")
    try:
        nb_model = NaiveBayesClassifier()
        nb_model.load("nb_model.json")
        print("Model loaded successfully!")
    except FileNotFoundError:
        print("Error: nb_model.json not found. Make sure to run train_naive_bayes.py first.")
        sys.exit(1)

    server_address = ('', port)
    httpd = HTTPServer(server_address, HateSpeechHandler)
    print(f"Starting server on http://localhost:{port}...")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    print("\nStopping server...")
    httpd.server_close()

if __name__ == '__main__':
    run_server()
