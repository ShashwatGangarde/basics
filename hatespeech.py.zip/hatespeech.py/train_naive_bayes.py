import pandas as pd
import math
import random
from collections import defaultdict
import json

def train_test_split_custom(data, test_ratio=0.2):
    random.seed(42)
    random.shuffle(data)
    test_size = int(len(data) * test_ratio)
    test_set = data[:test_size]
    train_set = data[test_size:]
    return train_set, test_set

class NaiveBayesClassifier:
    def __init__(self):
        self.class_counts = defaultdict(int)
        self.word_counts = defaultdict(lambda: defaultdict(int))
        self.vocab = set()
        self.total_docs = 0
        
    def save(self, filepath):
        model_data = {
            'class_counts': dict(self.class_counts),
            'word_counts': {k: dict(v) for k, v in self.word_counts.items()},
            'vocab': list(self.vocab),
            'total_docs': self.total_docs
        }
        with open(filepath, 'w') as f:
            json.dump(model_data, f)
            
    def load(self, filepath):
        with open(filepath, 'r') as f:
            model_data = json.load(f)
            
        self.class_counts = defaultdict(int, {int(k): v for k, v in model_data['class_counts'].items()})
        self.word_counts = defaultdict(lambda: defaultdict(int))
        for k, v in model_data['word_counts'].items():
            self.word_counts[int(k)] = defaultdict(int, v)
        self.vocab = set(model_data['vocab'])
        self.total_docs = model_data['total_docs']
        
    def fit(self, X, y):
        for text, label in zip(X, y):
            self.class_counts[label] += 1
            self.total_docs += 1
            words = str(text).split()
            for word in words:
                self.word_counts[label][word] += 1
                self.vocab.add(word)
                
    def predict(self, X):
        predictions = []
        vocab_size = len(self.vocab)
        for text in X:
            best_label = None
            max_prob = -float('inf')
            words = str(text).split()
            
            for label in self.class_counts:
                # Log prior probability: P(class)
                prob = math.log(self.class_counts[label] / self.total_docs)
                
                # Total words in this class
                total_words_in_class = sum(self.word_counts[label].values())
                
                # Add log likelihood of each word with Laplace smoothing
                for word in words:
                    count = self.word_counts[label].get(word, 0)
                    prob += math.log((count + 1) / (total_words_in_class + vocab_size))
                    
                if prob > max_prob:
                    max_prob = prob
                    best_label = label
                    
            predictions.append(best_label)
        return predictions

def main():
    print("Loading data...")
    df = pd.read_csv("cleaned_data.csv")
    df.dropna(subset=['cleaned_tweet'], inplace=True)
    
    data = list(zip(df['cleaned_tweet'], df['class']))
    train_data, test_data = train_test_split_custom(data)
    
    X_train = [item[0] for item in train_data]
    y_train = [item[1] for item in train_data]
    
    X_test = [item[0] for item in test_data]
    y_test = [item[1] for item in test_data]
    
    print(f"Training on {len(X_train)} samples...")
    nb = NaiveBayesClassifier()
    nb.fit(X_train, y_train)
    
    print("Predicting on test set...")
    y_pred = nb.predict(X_test)
    
    correct = sum(1 for p, t in zip(y_pred, y_test) if p == t)
    accuracy = correct / len(y_test)
    print(f"\nOverall Accuracy: {accuracy:.4f}")
    
    print("\nSaving model to nb_model.json...")
    nb.save("nb_model.json")
    
    print("\nPhase 2 and 3 complete using pure Python Naive Bayes!")

if __name__ == "__main__":
    main()
