import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
import pickle

def main():
    input_file = "cleaned_data.csv"
    model_file = "hate_speech_model.pkl"
    vectorizer_file = "tfidf_vectorizer.pkl"

    print(f"Loading cleaned data from {input_file}...")
    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        print(f"Error: Could not find {input_file}. Please run Phase 1 first.")
        return

    # Drop any rows where cleaned_tweet is NaN (can happen if a tweet was just URLs/mentions)
    initial_len = len(df)
    df.dropna(subset=['cleaned_tweet'], inplace=True)
    if len(df) < initial_len:
        print(f"Dropped {initial_len - len(df)} rows with empty text after cleaning.")

    X = df['cleaned_tweet']
    y = df['class']

    print("Splitting dataset into training and testing sets (80/20)...")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    print(f"Training samples: {len(X_train)}")
    print(f"Testing samples: {len(X_test)}")

    print("\nInitializing TF-IDF Vectorizer...")
    # max_features limits vocabulary size to speed up training, ngram_range includes bi-grams
    vectorizer = TfidfVectorizer(max_features=10000, ngram_range=(1, 2))
    
    print("Fitting vectorizer and transforming training data...")
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    print("\nTraining Logistic Regression model...")
    # class_weight='balanced' handles imbalanced datasets (hate speech is usually rare)
    model = LogisticRegression(max_iter=1000, class_weight='balanced', random_state=42)
    model.fit(X_train_tfidf, y_train)

    print("\nEvaluating model on test set...")
    y_pred = model.predict(X_test_tfidf)
    
    print("-" * 50)
    print("Classification Report:")
    # 0 - Hate Speech, 1 - Offensive Language, 2 - Neither
    target_names = ['Hate Speech (0)', 'Offensive Language (1)', 'Neither (2)']
    print(classification_report(y_test, y_pred, target_names=target_names))
    
    acc = accuracy_score(y_test, y_pred)
    print(f"Overall Accuracy: {acc:.4f}")
    print("-" * 50)

    print(f"\nSaving model to {model_file} and vectorizer to {vectorizer_file}...")
    with open(model_file, 'wb') as f:
        pickle.dump(model, f)
    with open(vectorizer_file, 'wb') as f:
        pickle.dump(vectorizer, f)
        
    print("Training phase complete!")

if __name__ == "__main__":
    main()
