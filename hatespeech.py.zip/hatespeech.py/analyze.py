import pandas as pd
import sys

def main():
    try:
        df = pd.read_csv("labeled_data.csv")
        print("Dataset loaded successfully.")
        print(f"Total rows: {len(df)}")
        print("\nClass Distribution:")
        print("0 - Hate Speech")
        print("1 - Offensive Language")
        print("2 - Neither")
        print(df['class'].value_counts().sort_index())
        
        print("\nSample tweets by class:")
        for c in [0, 1, 2]:
            sample = df[df['class'] == c].sample(1).iloc[0]
            print(f"--- Class {c} ---")
            print(sample['tweet'])
            print()
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
