import pandas as pd
import re

def clean_text(text):
    """
    Cleans the input text by removing mentions, URLs, special characters,
    and converting to lowercase.
    """
    if not isinstance(text, str):
        return ""
    
    # Remove user mentions (@username)
    text = re.sub(r'@[A-Za-z0-9_]+', '', text)
    # Remove URLs
    text = re.sub(r'https?://\S+|www\.\S+', '', text)
    # Remove 'RT' (retweet tag)
    text = re.sub(r'\bRT\b', '', text)
    # Remove special characters and numbers, keep only letters and spaces
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    # Convert to lowercase
    text = text.lower()
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def main():
    input_file = "labeled_data.csv"
    output_file = "cleaned_data.csv"
    
    print(f"Loading data from {input_file}...")
    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        print(f"Error: Could not find {input_file}. Make sure you are in the correct directory.")
        return
        
    print(f"Total rows loaded: {len(df)}")
    print("\nOriginal text sample:")
    print(df['tweet'].head())
    
    print("\nCleaning text data (this may take a few seconds)...")
    # Apply the clean_text function to the tweet column
    df['cleaned_tweet'] = df['tweet'].apply(clean_text)
    
    print("\nCleaned text sample:")
    print(df['cleaned_tweet'].head())
    
    # Save the cleaned data to a new CSV
    df.to_csv(output_file, index=False)
    print(f"\nCleaned data successfully saved to {output_file}")

if __name__ == "__main__":
    main()
